package HamaniKhalilTP3;

public interface HashTable {
	
	public void	put(char key, int value) throws Exception;
	public int	get(char key);
	public void remove(char key);
}
